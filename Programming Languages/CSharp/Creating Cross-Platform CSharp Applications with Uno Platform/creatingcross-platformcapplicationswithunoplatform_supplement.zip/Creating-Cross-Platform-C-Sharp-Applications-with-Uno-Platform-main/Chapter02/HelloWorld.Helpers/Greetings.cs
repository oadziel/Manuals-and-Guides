namespace HelloWorld.Helpers
{
    public class Greetings
    {
        public static string GetStandardGreeting()
        {
            return "Hello from a cross platform library!";
        }
    }
}
