# Chapter 6 sample - Dashboard

The solution for this chapter also includes a reference to the source code from [github.com/syncfusion/Uno.SfChart](https://github.com/syncfusion/Uno.SfChart).

To compile this example, you'll need both projects cloned to the same root directory, as is shown in the image below.

![both repositories cloned to the same local root directory](https://user-images.githubusercontent.com/189547/121353454-c9b53100-c925-11eb-80c3-fba5d7211f57.png)

_It doesn't need to be this exact path, and you can have other repos there too._

Without this, the relative path to the SfChart project will be invalid.

Also, be sure to update the version of `Uno.UI` referenced by the `Syncfusion.SfChart.Uno` project.
