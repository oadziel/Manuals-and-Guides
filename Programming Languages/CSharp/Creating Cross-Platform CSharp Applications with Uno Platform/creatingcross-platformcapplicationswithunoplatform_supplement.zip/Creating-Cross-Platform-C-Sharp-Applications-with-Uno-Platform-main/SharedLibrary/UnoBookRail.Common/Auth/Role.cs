﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnoBookRail.Common.Auth
{
    public enum Role
    {
        Unknown,
        HR,
        PR,
        IT,
        Accounting,
        Drivers,
        Engineering,
        Cleaning
    }
}
