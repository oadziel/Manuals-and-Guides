﻿namespace UnoBookRail.Common.Issues
{
    public enum IssueType
    {
        Train,
        Station,
        Other
    }
}
