﻿
namespace UnoBookRail.Common.Issues
{
    public enum Urgency
    {
        Critical,
        Medium,
        Low
    }
}
