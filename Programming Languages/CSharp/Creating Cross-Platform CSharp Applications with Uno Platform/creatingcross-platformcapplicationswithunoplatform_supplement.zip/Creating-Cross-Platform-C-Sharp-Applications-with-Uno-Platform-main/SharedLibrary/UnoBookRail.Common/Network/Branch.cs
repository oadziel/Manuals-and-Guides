﻿namespace UnoBookRail.Common.Network
{
    public enum Branch
    {
        MainLine,
        NorthBranch,
        SouthBranch,
    }
}
