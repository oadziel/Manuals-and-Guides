﻿namespace UnoBookRail.Common.Network
{
    public enum CompassDirection
    {
        East,
        West,
        North,
        South,
    }
}
