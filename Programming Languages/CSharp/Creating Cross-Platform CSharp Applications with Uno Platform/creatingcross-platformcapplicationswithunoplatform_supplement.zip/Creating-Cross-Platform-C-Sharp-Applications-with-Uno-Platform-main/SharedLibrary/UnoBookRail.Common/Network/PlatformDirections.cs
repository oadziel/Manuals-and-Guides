﻿namespace UnoBookRail.Common.Network
{
    public enum PlatformDirections
    {
        EastWest,
        NorthSouth,
    }
}
