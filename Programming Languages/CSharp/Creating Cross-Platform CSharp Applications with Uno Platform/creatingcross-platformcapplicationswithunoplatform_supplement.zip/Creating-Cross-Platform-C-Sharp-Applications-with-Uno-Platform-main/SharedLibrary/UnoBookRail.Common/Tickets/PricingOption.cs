﻿namespace UnoBookRail.Common.Tickets
{
    public class PricingOption
    {
        public PricingOptionType OptionType;
        public string Price;
    }
}
