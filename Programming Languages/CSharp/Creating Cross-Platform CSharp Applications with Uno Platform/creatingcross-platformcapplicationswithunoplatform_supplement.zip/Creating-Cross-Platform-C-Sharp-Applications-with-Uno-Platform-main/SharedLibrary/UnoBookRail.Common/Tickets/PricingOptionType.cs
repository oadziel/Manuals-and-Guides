﻿
namespace UnoBookRail.Common.Tickets
{
    public enum PricingOptionType
    {
        AdultSingleTrip,
        AdultRoundTrip,
        ChildSingleTrip,
        ChildRoundTrip,
        Plus65SingleTrip,
        Plus65RoundTrip,
    }
}
