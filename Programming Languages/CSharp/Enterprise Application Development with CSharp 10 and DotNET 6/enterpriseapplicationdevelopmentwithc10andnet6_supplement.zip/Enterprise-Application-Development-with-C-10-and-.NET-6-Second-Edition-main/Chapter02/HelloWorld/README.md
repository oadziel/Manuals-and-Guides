### Chapter 2 Sample: *HelloWorld* console application
To create a new console application **HelloWorld**, execute following commands in .NET CLI

`dotnet new console --name HelloWorld`

Execute following CLI command to run **HelloWorld** project

  `dotnet run --project ./HelloWorld/HelloWorld.csproj`