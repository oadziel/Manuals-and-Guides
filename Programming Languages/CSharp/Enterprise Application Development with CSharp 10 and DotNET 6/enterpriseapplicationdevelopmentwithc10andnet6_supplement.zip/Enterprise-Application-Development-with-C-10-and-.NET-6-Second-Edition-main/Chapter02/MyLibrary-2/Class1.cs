﻿using System;

namespace MyLibrary_2
{
    public class Class1
    {

    }
}
