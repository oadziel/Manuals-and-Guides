﻿using System;

namespace MyLibrary_3
{
    public class Class1
    {

    }
}
