﻿namespace LambdaExpression;

public record class Person();
public record class Employee() : Person();
public record class Manager() : Person();

