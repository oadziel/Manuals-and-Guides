﻿namespace RecordStruct;
public record struct Employee(string FirstName, string LastName);
