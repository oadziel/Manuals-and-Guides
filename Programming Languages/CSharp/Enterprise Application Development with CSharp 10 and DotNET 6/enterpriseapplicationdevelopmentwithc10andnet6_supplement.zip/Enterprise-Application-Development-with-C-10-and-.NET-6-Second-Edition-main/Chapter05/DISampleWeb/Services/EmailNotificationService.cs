﻿namespace Microsoft.Extensions.DependencyInjection
{
    public class EmailNotificationService : INotificationService
    {
    }
}