﻿namespace DISampleWeb
{
    public interface IWeatherForcastService
    {
    }
}