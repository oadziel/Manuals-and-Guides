﻿namespace Microsoft.Extensions.DependencyInjection
{
    public class SMSNotificationService: INotificationService
    {
    }
}