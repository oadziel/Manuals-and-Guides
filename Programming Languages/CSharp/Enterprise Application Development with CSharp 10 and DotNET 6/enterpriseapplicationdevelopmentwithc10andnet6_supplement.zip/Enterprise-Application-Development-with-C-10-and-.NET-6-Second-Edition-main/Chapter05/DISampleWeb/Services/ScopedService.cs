﻿namespace DISampleWeb.Services
{
    /// <summary>
    /// Service that will be registered as Scoped Service
    /// </summary>
    public interface IScopedService
    {
    }
    public class ScopedService : IScopedService
    {
    }
}
