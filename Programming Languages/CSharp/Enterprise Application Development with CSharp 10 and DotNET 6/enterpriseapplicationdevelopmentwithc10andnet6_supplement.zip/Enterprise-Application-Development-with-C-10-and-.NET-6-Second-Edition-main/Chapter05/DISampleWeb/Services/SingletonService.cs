﻿namespace DISampleWeb.Services
{
    /// <summary>
    /// Service that will be registered as Singleton Service
    /// </summary>
    public interface ISingletonService
    {
    }
    public class SingletonService : ISingletonService
    {
    }
}
