﻿namespace DISampleWeb.Services
{
    /// <summary>
    /// Service that will be registered as Transient Service
    /// </summary>
    public interface ITransientService
    {
    }

    public class TransientService : ITransientService
    {
    }
}