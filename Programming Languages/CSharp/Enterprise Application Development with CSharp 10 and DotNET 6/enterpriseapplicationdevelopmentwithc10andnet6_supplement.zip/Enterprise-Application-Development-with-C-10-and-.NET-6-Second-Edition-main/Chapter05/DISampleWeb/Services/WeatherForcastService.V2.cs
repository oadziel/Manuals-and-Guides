﻿namespace DISampleWeb
{
    internal class WeatherForcastServiceV2 : IWeatherForcastService
    {
    }
}