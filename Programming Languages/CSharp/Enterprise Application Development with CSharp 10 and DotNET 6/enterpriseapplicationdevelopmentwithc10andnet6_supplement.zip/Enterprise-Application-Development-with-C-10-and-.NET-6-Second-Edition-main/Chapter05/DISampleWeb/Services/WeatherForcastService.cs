﻿namespace DISampleWeb
{
    internal class WeatherForcastService : IWeatherForcastService
    {
    }
}