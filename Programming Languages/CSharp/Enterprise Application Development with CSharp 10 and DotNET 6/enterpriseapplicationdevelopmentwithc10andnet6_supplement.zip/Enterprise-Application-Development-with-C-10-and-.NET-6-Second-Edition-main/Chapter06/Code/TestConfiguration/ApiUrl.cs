﻿namespace TestConfiguration
{
    public class ApiUrl
    {
        public string EndpointName { get; set; }
    }

}
