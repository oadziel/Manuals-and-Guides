﻿// "//-----------------------------------------------------------------------".
// <copyright file="globalusings.cs" company="Packt">
// Copyright (c) 2020 Packt Corporation. All rights reserved.
// </copyright>
// "//-----------------------------------------------------------------------".
global using Microsoft.ApplicationInsights;
global using Microsoft.AspNetCore.Mvc;
global using System.Collections.Generic;
global using System.ComponentModel.DataAnnotations;
global using System.Diagnostics;
global using System.Threading.Tasks;
