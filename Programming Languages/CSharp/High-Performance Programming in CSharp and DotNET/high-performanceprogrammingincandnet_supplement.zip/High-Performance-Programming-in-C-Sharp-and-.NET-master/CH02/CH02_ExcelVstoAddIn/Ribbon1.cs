﻿namespace CH02_ExcelVstoAddIn
{
    using Microsoft.Office.Core;
    using Microsoft.Office.Tools.Ribbon;

    public partial class Ribbon1 
    {
        private bool _ribbonCondition = false;

        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {

        }
    }
}
