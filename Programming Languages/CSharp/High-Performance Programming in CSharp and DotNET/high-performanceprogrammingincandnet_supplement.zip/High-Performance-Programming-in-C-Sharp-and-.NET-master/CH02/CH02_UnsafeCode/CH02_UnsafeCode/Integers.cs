﻿namespace CH02_UnsafeCode
{
    internal struct Integers
    {
        public int I, J;
    }
}
