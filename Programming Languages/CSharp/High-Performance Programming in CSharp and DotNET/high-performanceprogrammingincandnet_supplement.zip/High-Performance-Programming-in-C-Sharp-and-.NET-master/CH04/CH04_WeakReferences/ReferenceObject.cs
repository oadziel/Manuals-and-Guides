﻿namespace CH04_WeakReferences;

internal class ReferenceObject
{
    public int Id { get; set; }
    public string Name { get; set; }
}
