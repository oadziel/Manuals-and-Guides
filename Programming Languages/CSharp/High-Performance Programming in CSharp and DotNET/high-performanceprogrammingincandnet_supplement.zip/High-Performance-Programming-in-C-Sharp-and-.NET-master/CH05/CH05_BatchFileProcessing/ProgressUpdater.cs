﻿namespace CH05_BatchFileProcessing
{
    internal class ProgressUpdater
    {
        public int TotalFiles;
        public int CurrentFileNmb;
    }
}
