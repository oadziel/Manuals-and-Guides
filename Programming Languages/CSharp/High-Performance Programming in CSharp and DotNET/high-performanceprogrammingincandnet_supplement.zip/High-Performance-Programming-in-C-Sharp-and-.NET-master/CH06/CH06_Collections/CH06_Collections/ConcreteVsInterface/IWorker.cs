﻿namespace CH06_Collections.ConcreteVsInterface
{
	public interface IWorker
	{
		void DoWork();
	}
}
