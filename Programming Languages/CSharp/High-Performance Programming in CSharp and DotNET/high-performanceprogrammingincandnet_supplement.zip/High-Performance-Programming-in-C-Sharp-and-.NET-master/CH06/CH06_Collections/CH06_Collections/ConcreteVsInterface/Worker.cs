﻿namespace CH06_Collections.ConcreteVsInterface
{
	public class Worker : IWorker
	{
		public void DoWork()
		{
			
		}
	}
}
