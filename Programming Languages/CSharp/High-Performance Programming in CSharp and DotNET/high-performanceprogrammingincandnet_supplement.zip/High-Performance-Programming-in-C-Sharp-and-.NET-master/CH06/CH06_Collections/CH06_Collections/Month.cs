﻿namespace CH06_Collections
{
	internal class Month
	{
		public string Name { get; set; }
		public int MonthOfYear { get; set; }
	}
}
