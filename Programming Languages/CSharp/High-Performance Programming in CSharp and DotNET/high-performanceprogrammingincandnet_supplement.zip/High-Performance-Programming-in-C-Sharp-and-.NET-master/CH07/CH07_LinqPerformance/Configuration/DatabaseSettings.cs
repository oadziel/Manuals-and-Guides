﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace CH07_LinqPerformance.Configuration
{
	public class DatabaseSettings
	{
		public string ConnectionString { get; set; }
	}
}
