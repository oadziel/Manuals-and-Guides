﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH10_DataAccessBenchmarks.Configuration
{
    internal class DatabaseSettings
    {
        public string ConnectionString { get; set; }
    }
}
