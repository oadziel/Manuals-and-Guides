﻿using BenchmarkDotNet.Running;
using CH10_DataAccessBenchmarks;

BenchmarkRunner.Run<BenchmarkTests>();