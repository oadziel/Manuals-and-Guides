﻿namespace CH12_ResponsiveMAUI.Models
{
    using CH12_ResponsiveMAUI.Data;

    public class Person : BaseEntity
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
