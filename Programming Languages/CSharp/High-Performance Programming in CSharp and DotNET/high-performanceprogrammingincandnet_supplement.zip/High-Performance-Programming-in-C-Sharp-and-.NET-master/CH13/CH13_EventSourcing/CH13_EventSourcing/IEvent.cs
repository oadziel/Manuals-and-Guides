﻿namespace CH13_EventSourcing
{
    /// <summary>
    /// Tag a class with this interface so thatv it can be used as an event.
    /// </summary>
    public class IEvent
    {
    }
}
