# OpenWeatherClient
 An unofficial C# client for OpenWeather
