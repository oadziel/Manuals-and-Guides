﻿namespace Uqs.Arithmetic;

public class Division
{
    public static decimal Divide(int dividend, int divisor)
    {
        decimal quotient = (decimal)dividend / divisor;
        return quotient;
    }
}