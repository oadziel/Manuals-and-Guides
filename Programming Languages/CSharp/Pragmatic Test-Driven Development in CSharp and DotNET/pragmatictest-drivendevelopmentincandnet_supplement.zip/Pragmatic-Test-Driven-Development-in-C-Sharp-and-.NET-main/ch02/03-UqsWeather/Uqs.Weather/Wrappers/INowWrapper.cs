﻿namespace Uqs.Weather.Wrappers;

public interface INowWrapper
{
    DateTime Now { get; }
}

