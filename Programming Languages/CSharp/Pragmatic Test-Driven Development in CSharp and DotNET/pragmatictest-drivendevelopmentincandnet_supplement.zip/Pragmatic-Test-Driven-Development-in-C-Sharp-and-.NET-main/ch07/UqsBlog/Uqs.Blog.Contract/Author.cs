﻿namespace Uqs.Blog.Contract;

public record Author(int Id, string Name);