﻿namespace Uqs.Blog.Domain.DomainObjects;

public struct Tag
{
    public int Id { get; set; }
    public string Name { get; set; }
}