﻿namespace Uqs.AppointmentBooking.Contract;

public record AvailableServices(Service[] Services);