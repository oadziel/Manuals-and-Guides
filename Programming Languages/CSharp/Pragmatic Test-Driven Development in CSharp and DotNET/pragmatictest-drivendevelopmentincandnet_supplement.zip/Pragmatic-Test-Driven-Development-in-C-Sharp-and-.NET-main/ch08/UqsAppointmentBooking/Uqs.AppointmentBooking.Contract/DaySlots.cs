﻿namespace Uqs.AppointmentBooking.Contract;

public record DaySlots(DateTime Day, DateTime[] Times);