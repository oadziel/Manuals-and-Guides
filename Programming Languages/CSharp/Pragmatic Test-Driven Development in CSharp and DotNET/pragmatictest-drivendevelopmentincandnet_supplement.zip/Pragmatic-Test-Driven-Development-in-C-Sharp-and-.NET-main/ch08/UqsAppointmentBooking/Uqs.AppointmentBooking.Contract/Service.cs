﻿namespace Uqs.AppointmentBooking.Contract;

public record Service(int ServiceId, string Name, int Duration, float Price);