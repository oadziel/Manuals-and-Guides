﻿namespace Uqs.AppointmentBooking.Contract;

public record ServiceDetails(int ServiceId, string Name, float Price);
