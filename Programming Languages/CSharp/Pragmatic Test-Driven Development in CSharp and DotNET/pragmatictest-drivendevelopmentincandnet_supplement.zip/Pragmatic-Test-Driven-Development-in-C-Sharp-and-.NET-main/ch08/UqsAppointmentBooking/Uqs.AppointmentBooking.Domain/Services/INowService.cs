﻿namespace Uqs.AppointmentBooking.Domain.Services;

public interface INowService
{
    DateTime Now { get; }
}

