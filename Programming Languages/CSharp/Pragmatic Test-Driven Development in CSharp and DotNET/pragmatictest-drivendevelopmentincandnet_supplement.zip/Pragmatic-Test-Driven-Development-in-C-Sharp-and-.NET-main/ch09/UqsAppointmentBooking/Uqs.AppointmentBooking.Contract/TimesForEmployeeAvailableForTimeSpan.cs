﻿namespace Uqs.AppointmentBooking.Contract;

public class TimesForEmployeeAvailableForTimeSpan
{
}
