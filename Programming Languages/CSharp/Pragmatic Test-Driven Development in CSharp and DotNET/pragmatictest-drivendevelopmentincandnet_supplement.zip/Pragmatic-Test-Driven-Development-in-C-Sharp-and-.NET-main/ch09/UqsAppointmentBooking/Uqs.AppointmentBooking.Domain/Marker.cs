﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Uqs.AppointmentBooking.Domain.Tests.Unit")]