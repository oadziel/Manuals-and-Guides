﻿namespace Uqs.AppointmentBooking.Contract;

public record Employee(string? EmployeeId, string Name);