﻿namespace Uqs.AppointmentBooking.Contract;

public record Service(string? ServiceId, string Name, int Duration, float Price);