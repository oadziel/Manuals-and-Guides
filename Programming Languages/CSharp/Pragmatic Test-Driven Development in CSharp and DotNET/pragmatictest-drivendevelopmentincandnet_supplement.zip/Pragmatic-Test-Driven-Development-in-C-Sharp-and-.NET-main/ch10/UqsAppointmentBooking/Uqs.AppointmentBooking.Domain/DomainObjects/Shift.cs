﻿namespace Uqs.AppointmentBooking.Domain.DomainObjects;

public class Shift
{
    public DateTime Starting { get; set; }
    public DateTime Ending { get; set; }
}