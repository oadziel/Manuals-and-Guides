﻿
namespace DDD.ApplicationLayer
{
    public interface ICommand
    {
    }
}
