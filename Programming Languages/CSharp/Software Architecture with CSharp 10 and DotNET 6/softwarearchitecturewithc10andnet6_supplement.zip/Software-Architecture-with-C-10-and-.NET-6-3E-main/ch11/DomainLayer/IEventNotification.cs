﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DDD.DomainLayer
{
    public interface IEventNotification
    {
    }
}
