Code snippets you may use in your code to implement
DDD patterns 