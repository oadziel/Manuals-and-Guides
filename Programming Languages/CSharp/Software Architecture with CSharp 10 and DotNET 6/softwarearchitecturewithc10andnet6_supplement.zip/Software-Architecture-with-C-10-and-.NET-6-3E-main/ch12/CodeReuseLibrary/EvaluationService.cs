﻿namespace CodeReuseLibrary
{
    public class EvaluationService
    {
        public IContentEvaluated Content { get; set; }
        public int CalculateEvaluationAverage() =>
            0;
    }
}
