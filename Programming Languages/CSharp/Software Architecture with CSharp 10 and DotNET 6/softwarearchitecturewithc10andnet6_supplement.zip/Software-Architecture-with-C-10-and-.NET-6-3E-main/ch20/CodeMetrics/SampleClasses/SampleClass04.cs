﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeMetricsBadCode.SampleClasses
{
    class SampleClass04 : SampleClass03
    {
        /// <summary>
        /// This code does nothing, it is just a sample for testing code metrics.
        /// </summary>
        public override void DoJob()
        {

        }
    }
}
