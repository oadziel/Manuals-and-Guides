﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeMetricsGoodCode.CouplingSample.Execution
{
    class ExecutionTypeA : IExecutionType
    {
        public void Execute()
        {

        }
    }
}
