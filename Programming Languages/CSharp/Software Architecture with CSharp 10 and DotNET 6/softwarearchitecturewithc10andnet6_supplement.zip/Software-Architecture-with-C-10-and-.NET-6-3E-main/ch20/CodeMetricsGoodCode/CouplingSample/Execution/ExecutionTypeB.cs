﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeMetricsGoodCode.CouplingSample.Execution
{
    class ExecutionTypeB : IExecutionType
    {
        public void Execute()
        {

        }
    }
}
