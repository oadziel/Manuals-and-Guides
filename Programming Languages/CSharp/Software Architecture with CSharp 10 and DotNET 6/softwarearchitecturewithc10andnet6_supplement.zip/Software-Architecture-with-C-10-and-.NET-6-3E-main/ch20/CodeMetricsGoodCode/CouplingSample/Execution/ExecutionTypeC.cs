﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeMetricsGoodCode.CouplingSample.Execution
{
    class ExecutionTypeC : IExecutionType
    {
        public void Execute()
        {

        }
    }
}
