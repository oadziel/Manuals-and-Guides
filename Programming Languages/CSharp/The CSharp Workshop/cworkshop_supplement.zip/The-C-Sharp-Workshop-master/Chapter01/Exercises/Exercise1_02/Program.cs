﻿using System;

Console.WriteLine("Hi! I’m your first Program. What is your name?");

var name = Console.ReadLine();

Console.WriteLine($"Hi {name}, it is very nice to meet you. We have a really fun journey ahead.");