﻿namespace Chapter02.Examples.Abstraction
{
    public static class Demo
    {
        public static void Run()
        {
            Progress.Demo.Run();
            Workers.Demo.Run();
        }
    }
}
