﻿namespace Chapter02.Examples.Abstraction.Workers
{
    public interface IDrone : IWorker, IFlyer
    {
    }
}
