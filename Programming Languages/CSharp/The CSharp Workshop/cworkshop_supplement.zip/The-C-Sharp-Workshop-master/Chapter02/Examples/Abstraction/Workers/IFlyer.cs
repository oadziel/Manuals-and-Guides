﻿namespace Chapter02.Examples.Abstraction.Workers
{
    public interface IFlyer
    {
        void Fly();
    }
}
