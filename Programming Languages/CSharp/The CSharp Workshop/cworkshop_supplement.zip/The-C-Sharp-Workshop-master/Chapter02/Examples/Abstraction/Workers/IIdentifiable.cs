﻿namespace Chapter02.Examples.Abstraction.Workers
{
    public interface IIdentifiable
    {
        long Id { get; }
    }
}
