﻿namespace Chapter02.Examples.Abstraction.Workers
{
    public interface IWorker
    {
        void Work();
    }
}
