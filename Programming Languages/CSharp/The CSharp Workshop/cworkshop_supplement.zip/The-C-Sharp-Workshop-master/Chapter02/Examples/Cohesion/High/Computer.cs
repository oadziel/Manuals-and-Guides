﻿namespace Chapter02.Examples.Cohesion.High
{
    class Computer
    {
        private readonly Keyboard keyboard;
    }
}
