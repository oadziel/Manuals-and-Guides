﻿namespace Chapter02.Examples.Cohesion.High
{
    internal class Key
    {
    }
}