﻿// Used in pseudo-code example.
#pragma warning disable CS0169
namespace Chapter02.Examples.Cohesion.High
{
    internal class Keyboard
    {
        private readonly Key[] keys;
    }
}