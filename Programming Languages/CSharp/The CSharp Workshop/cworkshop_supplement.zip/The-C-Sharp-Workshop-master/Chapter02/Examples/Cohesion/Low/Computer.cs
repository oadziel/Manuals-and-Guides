﻿// Used in pseudo-code example.
#pragma warning disable CS0169
namespace Chapter02.Examples.Cohesion.Low
{
    class Computer
    {
        private readonly Key[] Keys;
    }
}