﻿namespace Chapter02.Examples.Cohesion.Low
{
    class Key
    {
    }
}