﻿namespace Chapter02.Examples.Cohesion.Low
{
    internal class Keyboard
    {
    }
}