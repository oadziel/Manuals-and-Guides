﻿namespace Chapter02.Examples.CsharpKeywords.DefaultInterface
{
    interface IMovingTile : ITile, IMotor
    {
    }
}
