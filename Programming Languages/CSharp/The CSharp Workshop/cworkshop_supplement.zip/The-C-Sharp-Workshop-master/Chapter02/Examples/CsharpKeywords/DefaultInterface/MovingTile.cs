﻿namespace Chapter02.Examples.CsharpKeywords.DefaultInterface
{
    public class MovingTile : IMovingTile
    {
    }
}
