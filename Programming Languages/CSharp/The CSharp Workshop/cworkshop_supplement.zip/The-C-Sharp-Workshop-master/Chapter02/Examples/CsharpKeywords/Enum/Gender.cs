﻿namespace Chapter02.Examples.CsharpKeywords.Enum
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
