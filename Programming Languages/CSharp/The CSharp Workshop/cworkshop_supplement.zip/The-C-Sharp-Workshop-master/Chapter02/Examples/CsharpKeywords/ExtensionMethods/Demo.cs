﻿namespace Chapter02.Examples.CsharpKeywords.ExtensionMethods
{
    public static class Demo
    {
        public static void Run()
        {
            "Hey".Print();
        }
    }
}
