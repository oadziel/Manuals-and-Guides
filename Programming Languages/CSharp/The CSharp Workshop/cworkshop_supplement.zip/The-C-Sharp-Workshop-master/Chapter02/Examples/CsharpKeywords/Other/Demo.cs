﻿namespace Chapter02.Examples.CsharpKeywords.Other
{
    public static class Demo
    {
        public static void Run()
        {
            NullablePrimitives.Demo.Run();
        }
    }
}
