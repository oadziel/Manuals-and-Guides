﻿namespace Chapter02.Examples.CsharpKeywords.PartialClasses
{
    public partial class BigClass
    {
        public void Method3() { }
    }
}
