

namespace Chapter02.Examples
{
    public class Demo
    {
        public static void Run()
        {
            Encapsulation.Demo.Run();
            InheritanceAndPolymorphism.Demo.Run();
            Abstraction.Demo.Run();
            CsharpKeywords.Demo.Run();
        }
    }
}