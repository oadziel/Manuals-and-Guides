﻿namespace Chapter02.Examples.InheritanceAndPolymorphism.Composition.Compliant;

class Motor
{
    public void Move() { }
}