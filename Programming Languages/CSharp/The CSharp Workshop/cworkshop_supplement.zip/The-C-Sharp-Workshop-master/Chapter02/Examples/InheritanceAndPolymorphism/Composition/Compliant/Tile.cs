﻿namespace Chapter02.Examples.InheritanceAndPolymorphism.Composition.Compliant
{
    class Tile
    {
    }
}
