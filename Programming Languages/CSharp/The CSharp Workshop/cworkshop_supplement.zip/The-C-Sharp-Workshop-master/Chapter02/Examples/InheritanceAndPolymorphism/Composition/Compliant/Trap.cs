﻿namespace Chapter02.Examples.InheritanceAndPolymorphism.Composition.Compliant;

class Trap
{
    public void Damage() { }
}