﻿namespace Chapter02.Examples.InheritanceAndPolymorphism.Composition.NotCompliant;

class MovingTile : Tile
{
    public void Move() {}
}