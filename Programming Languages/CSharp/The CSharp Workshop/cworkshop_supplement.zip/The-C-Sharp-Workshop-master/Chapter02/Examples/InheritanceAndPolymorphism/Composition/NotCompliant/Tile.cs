﻿namespace Chapter02.Examples.InheritanceAndPolymorphism.Composition.NotCompliant
{
    class Tile
    {
    }

    //class MovingTrapTile : ?
}
