﻿namespace Chapter02.Examples.InheritanceAndPolymorphism.Composition.NotCompliant;

class TrapTile : Tile
{
    public void Damage() {}
}