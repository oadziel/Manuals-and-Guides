﻿namespace Chapter02.Examples.InheritanceAndPolymorphism
{
    public class Foo
    {
    }
}
