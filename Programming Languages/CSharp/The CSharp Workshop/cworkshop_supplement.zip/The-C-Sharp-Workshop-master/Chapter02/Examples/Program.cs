namespace Chapter02.Examples
{
    public class Program
    {
        public static void Main()
        {
            Demo.Run();
        }
    }
}