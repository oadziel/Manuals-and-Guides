﻿namespace Chapter02.Examples.Solid.Breaking.Dip
{
    interface IReader
    {
        string Read(string filePath);
    }
}
