﻿namespace Chapter02.Examples.Solid.Breaking.Dip
{
    interface IWriter
    {
        void Write(string filePath, string content);
    }
}
