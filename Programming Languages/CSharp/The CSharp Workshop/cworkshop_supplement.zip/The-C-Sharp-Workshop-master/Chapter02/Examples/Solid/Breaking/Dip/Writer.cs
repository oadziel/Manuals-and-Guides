﻿namespace Chapter02.Examples.Solid.Breaking.Dip
{
    public class Writer
    {
        public virtual void Write(string filePath, string content)
        {
            // implementation how to append content to an existing file
            // complex logic
        }
    }
}
