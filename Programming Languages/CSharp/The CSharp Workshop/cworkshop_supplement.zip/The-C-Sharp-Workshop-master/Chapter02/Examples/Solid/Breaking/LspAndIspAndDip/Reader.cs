﻿namespace Chapter02.Examples.Solid.Breaking.LspAndIspAndDip
{
    public class Reader
    {
        public virtual string Read(string filePath)
        {
            // implementation how to read file contents
            // complex logic
            return "";
        }
    }
}
