﻿namespace Chapter02.Examples.Solid.Breaking.OcpAndLspAndIspAndDip
{
    public class Reader
    {
        public string Read(string filePath)
        {
            // implementation how to read file contents
            // complex logic
            return "";
        }
    }
}
