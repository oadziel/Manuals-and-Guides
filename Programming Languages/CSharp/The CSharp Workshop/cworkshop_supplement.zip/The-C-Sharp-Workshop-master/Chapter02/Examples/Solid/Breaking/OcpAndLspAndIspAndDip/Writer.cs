﻿namespace Chapter02.Examples.Solid.Breaking.OcpAndLspAndIspAndDip
{
    public class Writer
    {
        public void Write(string filePath, string content)
        {
            // implementation how to append content to an existing file
            // complex logic
        }
    }
}
