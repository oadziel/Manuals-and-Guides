﻿namespace Chapter02.Examples.Solid.DependencyInjectionPrinciple;

public class Bartender : IBartender { }