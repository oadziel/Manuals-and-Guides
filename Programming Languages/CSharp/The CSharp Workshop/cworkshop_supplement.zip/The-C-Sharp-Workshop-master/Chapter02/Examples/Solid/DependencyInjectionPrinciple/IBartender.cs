﻿namespace Chapter02.Examples.Solid.DependencyInjectionPrinciple;

public interface IBartender { }