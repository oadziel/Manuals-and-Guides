﻿namespace Chapter02.Examples.Solid.FollowingAllPrinciples
{
    public interface IReader
    {
        string Read(string filePath);
    }
}
