﻿namespace Chapter02.Examples.Solid.FollowingAllPrinciples
{
    public interface IWriter
    {
        void Write(string filePath, string content);
    }
}
