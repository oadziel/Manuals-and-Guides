﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter02.Exercises.Exercise01
{
    public class Book
    {
        public string Title;
        public string Author;
        public string Publisher;
        public int Pages;
        public string Description;
    }
}
