﻿namespace Chapter02.Exercises.Exercise03
{
    public interface IShape
    {
        double Area { get; }
    }
}
