﻿namespace Chapter02.Exercises.Exercise04
{
    public record Temperature(double Degrees, TemperatureUnit Unit);
}
