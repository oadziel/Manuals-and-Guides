﻿namespace Chapter02.Exercises.Exercise04
{
    public enum TemperatureUnit
    {
        C,
        F,
        K
    }
}