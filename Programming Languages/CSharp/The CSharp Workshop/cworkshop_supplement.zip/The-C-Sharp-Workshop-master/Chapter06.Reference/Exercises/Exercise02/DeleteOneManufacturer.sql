﻿DELETE FROM Factory.Manufacturer 
WHERE Name = 'Wonderland' 