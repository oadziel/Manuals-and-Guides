﻿UPDATE Factory.Product SET Price = 1.6 
WHERE Name = 'Toy Car' 