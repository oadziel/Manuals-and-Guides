﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Chapter06.Examples.AdventureWorksProduction
{
    public partial class Vproductanddescription
    {
        public int? Productid { get; set; }
        public string Name { get; set; }
        public string Productmodel { get; set; }
        public string Cultureid { get; set; }
        public string Description { get; set; }
    }
}
