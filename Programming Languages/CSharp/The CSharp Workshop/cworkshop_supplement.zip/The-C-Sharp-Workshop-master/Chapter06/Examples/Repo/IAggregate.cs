﻿namespace Chapter06.Examples.Repo
{
    public interface IAggregate : IEntity
    {
    }
}