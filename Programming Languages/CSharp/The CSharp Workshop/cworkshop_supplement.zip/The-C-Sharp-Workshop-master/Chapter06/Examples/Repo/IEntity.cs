﻿namespace Chapter06.Examples.Repo
{
    public interface IEntity
    {
        int Id { get; }
    }
}