namespace ToDoListApp.Models;

public enum ETaskStatus
{
    ToDo,
    Doing,
    Done
}