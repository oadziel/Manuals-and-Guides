namespace ToDoListApp.ViewComponents;

public class StatsViewModel
{
    public int Delayed { get; set; }
    public int DueToday { get; set; }
}
