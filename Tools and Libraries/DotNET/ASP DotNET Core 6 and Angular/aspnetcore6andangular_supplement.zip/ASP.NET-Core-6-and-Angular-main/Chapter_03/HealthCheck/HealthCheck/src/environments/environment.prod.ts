export const environment = {
  production: true,
  baseUrl: "https://localhost:40443/"
};
