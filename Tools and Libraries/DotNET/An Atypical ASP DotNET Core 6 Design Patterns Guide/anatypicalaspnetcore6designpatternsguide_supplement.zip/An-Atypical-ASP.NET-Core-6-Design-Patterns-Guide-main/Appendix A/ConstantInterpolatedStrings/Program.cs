﻿const string DotNetVersion = "6";
const string BookTitle = $"An Atypical ASP.NET Core {DotNetVersion} Design Patterns Guide";

Console.WriteLine(BookTitle);
