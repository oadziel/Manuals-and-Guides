﻿global using GlobalUsingDirectives.SomeCoolNamespace;
