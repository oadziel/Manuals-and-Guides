﻿namespace MyMinimalApiApp;

public class SomeOtherClass
{

}
