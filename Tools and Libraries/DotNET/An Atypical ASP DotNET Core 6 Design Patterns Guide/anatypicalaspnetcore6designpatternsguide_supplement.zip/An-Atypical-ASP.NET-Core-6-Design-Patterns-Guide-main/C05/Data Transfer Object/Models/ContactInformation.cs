﻿namespace DTOs.Models;
public record class ContactInformation(
    string Firstname,
    string Lastname,
    string Email
);
