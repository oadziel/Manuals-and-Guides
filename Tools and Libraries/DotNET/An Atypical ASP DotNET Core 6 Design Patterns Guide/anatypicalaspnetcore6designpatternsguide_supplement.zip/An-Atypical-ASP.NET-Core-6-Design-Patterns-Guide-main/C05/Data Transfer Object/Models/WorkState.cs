﻿namespace DTOs.Models;

public enum WorkState
{
    New,
    InProgress,
    Completed
}
