﻿namespace Vehicles.Models
{
    public class HighGradeBike : IBike { }
}
