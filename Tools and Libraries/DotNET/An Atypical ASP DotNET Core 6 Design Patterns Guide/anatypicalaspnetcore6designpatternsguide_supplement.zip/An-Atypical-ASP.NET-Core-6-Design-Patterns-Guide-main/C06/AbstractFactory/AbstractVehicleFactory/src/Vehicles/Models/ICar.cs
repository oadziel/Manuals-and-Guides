﻿namespace Vehicles.Models
{
    public interface ICar { }
}
