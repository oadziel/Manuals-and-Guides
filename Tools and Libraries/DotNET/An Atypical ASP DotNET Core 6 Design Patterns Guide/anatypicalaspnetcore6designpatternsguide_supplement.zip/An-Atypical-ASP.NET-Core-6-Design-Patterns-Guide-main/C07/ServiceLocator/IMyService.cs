﻿namespace ServiceLocator;

public interface IMyService : IDisposable
{
    void Execute();
}
