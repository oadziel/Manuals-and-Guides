﻿namespace CommonScenarios;

public class MyDoubleNameOptions
{
    public string? FirstName { get; set; }
    public string? SecondName { get; set; }
}
