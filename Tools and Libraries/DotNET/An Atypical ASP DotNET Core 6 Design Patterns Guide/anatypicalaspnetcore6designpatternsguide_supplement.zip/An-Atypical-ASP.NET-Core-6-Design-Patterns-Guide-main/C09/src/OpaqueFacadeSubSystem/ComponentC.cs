﻿namespace OpaqueFacadeSubSystem;

internal class ComponentC
{
    public string OperationE() => "Component C, Operation E";
    public string OperationF() => "Component C, Operation F";
}
