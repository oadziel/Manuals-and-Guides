﻿namespace FinalChainOfResponsibility;

public record class Message(string Name, string? Payload);
