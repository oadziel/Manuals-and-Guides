﻿namespace ImprovedChainOfResponsibility;

public record class Message(string Name, string? Payload);
