﻿namespace ApiGateway
{
    public enum ClientStatus
    {
        OFFLINE = 0,
        ONLINE = 1,
        BUSY = 2,
    }
}
