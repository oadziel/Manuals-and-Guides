﻿using System;
namespace ApiGateway
{
    public class ClientStatusModel
    {
        public string Name { get; set; }
        public ClientStatus Status { get; set; }
    }
}
