﻿namespace ApiGateway
{
    public class JobModel
    {
        public int JobId { get; set; }
        public string JobDescription { get; set; }
    }
}
