﻿namespace ApiGateway
{
    public class ApiResponse
    {
        public int DataItemsProcessed { get; set; }
        public double RequestProcessingTime { get; set; }
    }
}
