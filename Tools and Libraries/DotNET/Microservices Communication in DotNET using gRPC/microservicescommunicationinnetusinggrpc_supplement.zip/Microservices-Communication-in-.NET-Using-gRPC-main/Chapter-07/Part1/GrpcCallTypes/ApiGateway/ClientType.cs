﻿namespace ApiGateway
{
    public enum ClientType
    {
        PackageName = 0,
        NoPackage = 1,
        CsNamespace = 2
    }
}
